# TinyLink - Express Version (ready for GitHub)

This repository contains an Express + Postgres implementation of the TinyLink take-home assignment.

## Quick start (local)
1. Copy `.env.example` to `.env` and set `DATABASE_URL` (Postgres) and optional `PORT` and `BASE_URL`.
2. Run the SQL in `db.sql` once to create the `links` table, or let your DB admin do it.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the server:
   ```bash
   npm start
   ```
   or for development:
   ```bash
   npm run dev
   ```
5. Open `http://localhost:3000` and use the UI.

## Automated tests
With server running, run:
```
node tests/check.js
```

## Endpoints
- `GET  /healthz`
- `POST /api/links`
- `GET  /api/links`
- `GET  /api/links/:code`
- `DELETE /api/links/:code`
- `GET  /:code` (redirect)

## Notes
- Uses `pg` and expects `DATABASE_URL` env var to be set to a Postgres database.
- When deploying to platforms like Render or Railway, set `DATABASE_URL` and `PORT` in environment settings.
