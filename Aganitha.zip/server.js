/**
 * TinyLink - Express + Postgres implementation
 *
 * Endpoints:
 * GET  /healthz
 * POST /api/links      -> create link (409 if code exists)
 * GET  /api/links      -> list all links
 * GET  /api/links/:code-> get single link stats
 * DELETE /api/links/:code -> delete
 * GET  /:code -> redirect (302) or 404
 *
 * Requirements: set DATABASE_URL in env (Postgres), optional PORT and BASE_URL
 */
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import { Pool } from 'pg';
import { URL } from 'url';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('DATABASE_URL is not set. Copy .env.example to .env and set it.');
  process.exit(1);
}

const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false });

// Utility
const CODE_REGEX = /^[A-Za-z0-9]{6,8}$/;

// Health
app.get('/healthz', (req, res) => {
  res.json({ ok: true, version: '1.0' });
});

// Create link
app.post('/api/links', async (req, res) => {
  const { url, code } = req.body || {};
  if (!url || typeof url !== 'string') return res.status(400).json({ error: 'url required' });

  // validate url
  try {
    const parsed = new URL(url);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('invalid protocol');
  } catch (e) {
    return res.status(400).json({ error: 'invalid url' });
  }

  let finalCode = code;
  if (finalCode) {
    if (!CODE_REGEX.test(finalCode)) return res.status(400).json({ error: 'code must match [A-Za-z0-9]{6,8}' });
    // check unique
    try {
      const r = await pool.query('SELECT * FROM links WHERE code = $1', [finalCode]);
      if (r.rows.length > 0) return res.status(409).json({ error: 'code already exists' });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: 'db error' });
    }
  } else {
    // generate random 6 char code
    const alph = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const gen = (len) => Array.from({ length: len }, () => alph[Math.floor(Math.random() * alph.length)]).join('');
    let tries = 0;
    while (tries < 5) {
      finalCode = gen(6);
      const r = await pool.query('SELECT * FROM links WHERE code = $1', [finalCode]);
      if (r.rows.length === 0) break;
      tries++;
    }
    if (!finalCode) return res.status(500).json({ error: 'could not generate code' });
  }

  try {
    const insert = await pool.query(
      'INSERT INTO links(code, url) VALUES($1, $2) RETURNING id, code, url, clicks, last_clicked, created_at',
      [finalCode, url]
    );
    return res.status(201).json(insert.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'code already exists' });
    console.error(e);
    return res.status(500).json({ error: 'db error' });
  }
});

// List links
app.get('/api/links', async (req, res) => {
  try {
    const r = await pool.query('SELECT id, code, url, clicks, last_clicked, created_at FROM links ORDER BY created_at DESC');
    return res.json(r.rows);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'db error' });
  }
});

// Get single link stats
app.get('/api/links/:code', async (req, res) => {
  const { code } = req.params;
  try {
    const r = await pool.query('SELECT id, code, url, clicks, last_clicked, created_at FROM links WHERE code = $1', [code]);
    if (r.rows.length === 0) return res.status(404).json({ error: 'not found' });
    return res.json(r.rows[0]);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'db error' });
  }
});

// Delete link
app.delete('/api/links/:code', async (req, res) => {
  const { code } = req.params;
  try {
    const r = await pool.query('DELETE FROM links WHERE code = $1 RETURNING id', [code]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'not found' });
    return res.status(204).end();
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'db error' });
  }
});

// Redirect route (must be after API routes and static)
app.get('/:code', async (req, res) => {
  const { code } = req.params;
  // Don't treat common static files or API as redirect
  if (code === 'api' || code === 'healthz') return res.status(404).send('Not found');

  try {
    const r = await pool.query('SELECT id, code, url FROM links WHERE code = $1', [code]);
    if (r.rows.length === 0) return res.status(404).send('Not found');
    const link = r.rows[0];
    // update clicks and last_clicked
    await pool.query('UPDATE links SET clicks = clicks + 1, last_clicked = now() WHERE code = $1', [code]);
    return res.redirect(302, link.url);
  } catch (e) {
    console.error(e);
    return res.status(500).send('server error');
  }
});

// Fallback: serve index
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`TinyLink Express running on port ${PORT}`);
});
