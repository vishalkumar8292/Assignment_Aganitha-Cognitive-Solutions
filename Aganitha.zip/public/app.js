async function fetchLinks() {
  const el = document.getElementById('links');
  el.innerText = 'Loading...';
  const res = await fetch('/api/links');
  const links = await res.json();
  if (!links || links.length === 0) {
    el.innerText = 'No links yet';
    return;
  }
  const table = document.createElement('table');
  table.className = 'linksTable';
  const th = document.createElement('tr');
  th.innerHTML = '<th>Code</th><th>Target</th><th>Clicks</th><th>Last clicked</th><th>Actions</th>';
  table.appendChild(th);
  for (const l of links) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td><a href="/'+l.code+'" target="_blank">'+l.code+'</a></td>' +
      '<td class="truncate">'+l.url+'</td>' +
      '<td>'+l.clicks+'</td>' +
      '<td>'+(l.last_clicked ? new Date(l.last_clicked).toLocaleString() : 'Never')+'</td>' +
      '<td><button data-code="'+l.code+'" class="del">Delete</button> <a href="/code/'+l.code+'">Stats</a></td>';
    table.appendChild(tr);
  }
  el.innerHTML = '';
  el.appendChild(table);

  document.querySelectorAll('.del').forEach(b => b.addEventListener('click', async (e) => {
    const code = e.target.dataset.code;
    if (!confirm('Delete ' + code + '?')) return;
    await fetch('/api/links/' + code, { method: 'DELETE' });
    fetchLinks();
  }));
}

document.getElementById('createForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const url = document.getElementById('url').value;
  const code = document.getElementById('code').value;
  const btn = document.getElementById('createBtn');
  btn.disabled = true;
  const msg = document.getElementById('msg');
  msg.innerText = '';
  const res = await fetch('/api/links', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ url, code: code || undefined })});
  if (res.status === 201) {
    const data = await res.json();
    msg.innerText = 'Created ' + data.code + ' → /' + data.code;
    document.getElementById('url').value = '';
    document.getElementById('code').value = '';
    fetchLinks();
  } else {
    const body = await res.json();
    msg.innerText = body.error || 'error';
  }
  btn.disabled = false;
});

// initial load
fetchLinks();
