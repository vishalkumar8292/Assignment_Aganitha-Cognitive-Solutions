/**
 * Automated test for TinyLink autograder rules.
 * Usage: set DATABASE_URL and PORT (if different). Start server, then run: node tests/check.js
 *
 * This script will:
 * 1. Check GET /healthz -> 200 and ok:true
 * 2. Create a link via POST /api/links
 * 3. Attempt duplicate code -> expect 409
 * 4. GET /:code -> expect 302 redirect and increments clicks
 * 5. GET /api/links/:code -> check clicks >=1
 * 6. DELETE /api/links/:code -> 204
 * 7. GET /:code -> 404
 */
const fetch = globalThis.fetch || (await import('node-fetch')).default;
const BASE = process.env.BASE_URL || 'http://localhost:3000';

function log(...args){ console.log(...args); }

async function assert(cond, msg) {
  if (!cond) {
    console.error('FAILED:', msg);
    process.exit(1);
  }
}

async function run() {
  console.log('1) Healthz');
  let r = await fetch(BASE + '/healthz');
  await assert(r.status === 200, '/healthz not 200');
  const hv = await r.json();
  await assert(hv.ok === true, 'healthz ok !== true');

  console.log('2) Create link with custom code test123');
  const code = 'test' + Math.floor(Math.random()*900+100).toString().slice(0,4);
  r = await fetch(BASE + '/api/links', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ url: 'https://example.com', code: code })});
  await assert(r.status === 201, 'create failed ' + (await r.text()));
  const created = await r.json();
  await assert(created.code === code, 'created code mismatch');

  console.log('3) Duplicate create should 409');
  r = await fetch(BASE + '/api/links', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ url: 'https://example.com', code: code })});
  await assert(r.status === 409, 'duplicate did not return 409');

  console.log('4) Redirect should 302 and increment click');
  r = await fetch(BASE + '/' + code, { method: 'GET', redirect: 'manual' });
  await assert(r.status === 302 || r.status === 301, 'redirect did not return 302/301, got ' + r.status);
  const loc = r.headers.get('location');
  await assert(loc && loc.includes('example.com'), 'redirect location incorrect');

  console.log('5) Stats shows clicks >= 1');
  r = await fetch(BASE + '/api/links/' + code);
  await assert(r.status === 200, 'get single failed');
  const stats = await r.json();
  await assert(typeof stats.clicks === 'number' && stats.clicks >= 1, 'clicks not incremented');

  console.log('6) Delete link');
  r = await fetch(BASE + '/api/links/' + code, { method: 'DELETE' });
  await assert(r.status === 204, 'delete did not return 204');

  console.log('7) Redirect after delete returns 404');
  r = await fetch(BASE + '/' + code, { method: 'GET', redirect: 'manual' });
  await assert(r.status === 404, 'expected 404 after delete, got ' + r.status);

  console.log('All tests passed ✅');
}

run().catch(e => { console.error(e); process.exit(1); });
